module.exports = {
  secret: "descore-secret-key"
};
