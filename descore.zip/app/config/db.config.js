module.exports = {
  HOST: "traz.desacireundeucilograng.web.id",
  USER: "desacire_amatoxin",
  PASSWORD: "pvgCHkvSkL8gBMm",
  DB: "desacire_bantendb",
  dialect: "mysql",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};
